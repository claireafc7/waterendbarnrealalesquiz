// ales.js
export const ales = [
    {
        name: "Abbot",
        strengthCategory: 4.0,
        strength: "Between 3.5% ABV and 4.5% ABV",
        colour: "Golden",
        flavour: ["Fruity", "Malty", "Toffee"]
    },
    {
        name: "IPA",
        strengthCategory: 4.7,
        strength: "Between 4.5% ABV and 5.5% ABV",
        colour: "Amber",
        flavour: ["Hoppy", "Citrusy"]
    },
    {
        name: "Mutant",
        strengthCategory: 5.7,
        strength: "Above 5.5% ABV",
        colour: "Pale, Blond",
        flavour: ["Hoppy", "Malty", "Light"]
    },
    {
        name: "Doom Bar",
        strengthCategory: 3.4,
        strength: "Below 3.5% ABV",
        colour: "Golden",
        flavour: ["Citrusy", "Hoppy", "Toffee"]
    },
    {
        name: "Rocking Rudolph",
        strengthCategory: 4.8,
        strength: "Between 4.5% ABV and 5.5% ABV",
        colour: "Deep Ruby, Black",
        flavour: ["Citrusy", "Hoppy", "Dry"]
    },
    {
        name: "Rocking Mutant",
        strengthCategory: 5.7,
        strength: "Above 5.5% ABV",
        colour: "Pale, Blond",
        flavour: ["Citrusy", "Hoppy", "Dry"]
    },
     {
        name: "Brains SA",
        strengthCategory: 3.4,
        strength: "Below 3.5% ABV",
        colour: "Pale, Blond",
        flavour: ["Citrusy", "Hoppy", "Dry"]
    }
];
